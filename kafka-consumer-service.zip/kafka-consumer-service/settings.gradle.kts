rootProject.name = "kafka-consumer-service"
